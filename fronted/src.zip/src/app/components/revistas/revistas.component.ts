import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-revistas',
  templateUrl: './revistas.component.html',
  styleUrls: ['./revistas.component.css']
})
export class RevistasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
